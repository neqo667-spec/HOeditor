"""Characters — leaders, advisors, generals and admirals are all *characters*.

A character lives in ``common/characters/<TAG>.txt`` under ``characters = { <id> = {...} }``
and may carry any combination of roles: ``country_leader``, ``advisor``,
``field_marshal``/``corps_commander`` (general) and ``navy_leader`` (admiral), plus
``portraits`` (army/navy/civilian → large/small sprite names). A character becomes active
for a country via ``recruit_character`` in that country's history.

Responsibilities:
  * read every character (mod + game), resolving display names and portrait sprites;
  * report recruitment status across all countries (for the "unrecruited only" picker);
  * create / update / delete characters in the mod (the Characters editor);
Recruiting into history is delegated to `CountryService` so each service owns one tree.
"""
from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from ..config.constants import GAME_DIRS
from ..core.fspath import resolve_ci
from ..core.localisation import LocFile
from ..core.pdx import Block, Pair, Scalar, dump_file, parse_file
from ..domain.mod import ModContext
from ._locutil import find_loc_file_with_key, loc_write_target

GENERAL_ROLES = ("field_marshal", "corps_commander")
ROLE_KEYS = ("country_leader", "advisor", "field_marshal", "corps_commander", "navy_leader")
ADVISOR_SLOTS = ("political_advisor", "army_chief", "navy_chief", "air_chief",
                 "high_command", "theorist")
PORTRAIT_CATEGORIES = ("civilian", "army", "navy")
# Editable portrait slots: (category, size). ``small`` civilian is the advisor
# portrait shown in the political-advisor list; ``small`` army feeds the
# military-staff (army_chief/high_command/...) list.
PORTRAIT_SLOTS = (
    ("civilian", "large"), ("army", "large"), ("navy", "large"),
    ("civilian", "small"), ("army", "small"),
)


@dataclass
class CharacterModel:
    char_id: str
    tag: str
    name: str                       # resolved display name
    name_key: str                   # raw `name =` value
    roles: list[str] = field(default_factory=list)
    portraits: dict[str, dict[str, str]] = field(default_factory=dict)  # cat -> {size: sprite}
    in_mod: bool = False
    recruited_by: list[str] = field(default_factory=list)
    raw: Block | None = None        # source block, for prefilling the editor

    @property
    def roles_label(self) -> str:
        return ", ".join(self.roles) if self.roles else "—"

    def sprites(self) -> list[tuple[str, str, str]]:
        return [(cat, size, sprite)
                for cat, sizes in self.portraits.items()
                for size, sprite in sizes.items()]


class CharacterService:
    def __init__(self, context: ModContext):
        self.ctx = context
        self._chars: dict[str, CharacterModel] | None = None
        self._recruited: dict[str, list[str]] | None = None
        self._names: dict[str, str] | None = None
        self._sprites = context.sprites   # per-mod shared resolver (ModContext)

    # --- file location ---------------------------------------------------
    def characters_file(self, tag: str) -> Path:
        return self.ctx.mod.path / GAME_DIRS.CHARACTERS / f"{tag}.txt"

    # --- scanning --------------------------------------------------------
    def all_characters(self, refresh: bool = False) -> list[CharacterModel]:
        if self._chars is None or refresh:
            self._chars = self._scan_all()
            recruited = self.recruited_map(refresh)
            for cid, model in self._chars.items():
                model.recruited_by = recruited.get(cid, [])
        return list(self._chars.values())

    def get(self, char_id: str) -> CharacterModel | None:
        self.all_characters()
        return self._chars.get(char_id) if self._chars else None

    def _scan_all(self) -> dict[str, CharacterModel]:
        names = self._name_map()
        result: dict[str, CharacterModel] = {}
        for root, in_mod in self.ctx.override_layers(GAME_DIRS.CHARACTERS):
            folder = root / GAME_DIRS.CHARACTERS
            if not folder.is_dir():
                continue
            for file in folder.glob("*.txt"):
                try:
                    block = parse_file(file)
                except Exception:
                    continue
                chars = block.get_block("characters")
                if chars is None:
                    continue
                tag = file.stem.split("_")[0][:3].upper()
                for pair in chars.pairs():
                    if not isinstance(pair.value, Block):
                        continue
                    result[pair.key] = self._to_model(pair.key, pair.value, tag, in_mod, names)
        return result

    def _to_model(self, char_id, block: Block, tag, in_mod, names) -> CharacterModel:
        name_key = (block.get_scalar("name", "") or char_id).strip('"')
        roles = [r for r in ROLE_KEYS if block.get_block(r) is not None]
        portraits: dict[str, dict[str, str]] = {}
        pblock = block.get_block("portraits")
        if pblock is not None:
            for cat_pair in pblock.pairs():
                if isinstance(cat_pair.value, Block):
                    sizes = portraits.setdefault(cat_pair.key, {})
                    for size_pair in cat_pair.value.pairs():
                        if isinstance(size_pair.value, Scalar):
                            sizes[size_pair.key] = size_pair.value.raw
        # owner tag: prefer the id prefix when it looks like a TAG
        prefix = char_id.split("_")[0]
        owner = prefix.upper() if re.match(r"^[A-Za-z]{2,3}$", prefix) else tag
        return CharacterModel(
            char_id=char_id, tag=owner,
            name=names.get(name_key, name_key.replace("_", " ")),
            name_key=name_key, roles=roles, portraits=portraits, in_mod=in_mod, raw=block,
        )

    # --- recruitment status ---------------------------------------------
    def recruited_map(self, refresh: bool = False) -> dict[str, list[str]]:
        """char_id -> tags that recruit it, scanning every country's history."""
        if self._recruited is not None and not refresh:
            return self._recruited
        recruited: dict[str, list[str]] = {}
        for root in self.ctx.override_roots(GAME_DIRS.HISTORY_COUNTRIES):
            folder = root / GAME_DIRS.HISTORY_COUNTRIES
            if not folder.is_dir():
                continue
            for file in folder.glob("*.txt"):
                tag = file.stem.split(" ")[0]
                try:
                    text = file.read_text(encoding="utf-8-sig", errors="ignore")
                except OSError:
                    continue
                for m in re.finditer(r"recruit_character\s*=\s*([\w.\-]+)", text):
                    recruited.setdefault(m.group(1), [])
                    if tag not in recruited[m.group(1)]:
                        recruited[m.group(1)].append(tag)
        self._recruited = recruited
        return recruited

    def available_characters(self) -> list[CharacterModel]:
        """Characters recruited by no country (assignable elsewhere)."""
        self.all_characters()
        return [c for c in self._chars.values() if not c.recruited_by]

    def recruited_by_tag(self, tag: str) -> list[CharacterModel]:
        self.all_characters()
        return [c for c in self._chars.values() if tag in c.recruited_by]

    # --- portraits -------------------------------------------------------
    def resolve_sprite(self, sprite: str) -> Path | None:
        return self._sprites.resolve(sprite)

    # --- name localisation ----------------------------------------------
    def _name_map(self) -> dict[str, str]:
        if self._names is not None:
            return self._names
        names: dict[str, str] = {}
        for root in self.ctx.override_roots(GAME_DIRS.LOCALISATION):
            loc_dir = root / GAME_DIRS.LOCALISATION
            if not loc_dir.is_dir():
                continue
            for yml in loc_dir.glob("**/*characters*l_english.yml"):
                try:
                    loc = LocFile.load(yml)
                except Exception:
                    continue
                for entry in loc.entries():
                    names.setdefault(entry.key, entry.value)
        self._names = names
        return names

    def get_name_loc(self, name_key: str, language: str) -> str:
        """The character's display name in `language` (mod wins over vanilla)."""
        for root in self.ctx.search_roots(GAME_DIRS.LOCALISATION):
            yml = find_loc_file_with_key(root, language, name_key,
                                         name_hints=("character",) if root == self.ctx.game_path else ())
            if yml is not None:
                try:
                    return LocFile.load(yml).get(name_key, "") or ""
                except OSError:
                    continue
        return ""

    def set_name_loc(self, name_key: str, language: str, value: str) -> Path:
        """Write the display name for one language. Vanilla-defined keys are edited
        in a mod-side copy of the original file (override, no loc collision)."""
        path = loc_write_target(
            self.ctx.mod.path, self.ctx.game_path, language, name_key,
            f"{GAME_DIRS.LOCALISATION}/{language}/anka_characters_l_{language}.yml",
            name_hints=("character",), dep_roots=self.ctx.dependency_paths)
        loc = LocFile.load(path) if path.exists() else LocFile(language)
        loc.set(name_key, value)
        loc.save(path)
        if language == "english" and self._names is not None:
            self._names[name_key] = value
        return path

    # --- creation / editing ---------------------------------------------
    def create_or_update(
        self,
        tag: str,
        char_id: str,
        name: str,
        *,
        # (category, size) -> source image; a bare category string means "large".
        portraits: dict[tuple[str, str] | str, str | Path] | None = None,
        country_leader: dict | None = None,
        advisor: dict | None = None,
        general: dict | None = None,                       # includes "role": field_marshal|corps_commander
        admiral: dict | None = None,
    ) -> str:
        """Create or update a character with the given roles. Returns the char id."""
        tag = tag.upper()
        file = self.characters_file(tag)
        if not file.exists():
            self._seed_from_lower_layer(file)
        root = parse_file(file) if file.exists() else Block([Pair("characters", Block())])
        chars = root.get_block("characters") or Block()
        if root.get_block("characters") is None:
            root.add("characters", chars)

        character = chars.get_block(char_id) or Block()
        is_new = chars.get_block(char_id) is None
        character.set("name", Scalar(char_id))

        if portraits:
            pblock = character.get_block("portraits") or Block()
            for key, source in portraits.items():
                category, size = key if isinstance(key, tuple) else (key, "large")
                _dds, _gfx, sprite = self.ctx.icons.add_character_portrait(
                    source, char_id, tag, category, size=size)
                cat_block = pblock.get_block(category) or Block()
                cat_block.set(size, Scalar(sprite))
                if pblock.get_block(category) is None:
                    pblock.add(category, cat_block)
            character.set("portraits", pblock)

        self._apply_role(character, "country_leader", country_leader, self._build_country_leader)
        self._apply_role(character, "advisor", advisor, self._build_advisor)
        # general role: remove both, then add the chosen one
        character.remove("field_marshal")
        character.remove("corps_commander")
        if general:
            role = general.get("role", "corps_commander")
            character.set(role, self._build_general(general))
        self._apply_role(character, "navy_leader", admiral, self._build_navy_leader)

        if is_new:
            chars.add(char_id, character)
        file.parent.mkdir(parents=True, exist_ok=True)
        dump_file(root, file)

        # localisation of the display name (collision-safe, see set_name_loc)
        self.set_name_loc(char_id, "english", name)

        # Incremental cache update — no full rescan. Rebuild just this character's model.
        if self._names is not None:
            self._names[char_id] = name
        if self._chars is not None:
            model = self._to_model(char_id, character, tag, True, {})
            model.name = name
            model.recruited_by = (self._recruited or {}).get(char_id, [])
            self._chars[char_id] = model
        return char_id

    def _seed_from_lower_layer(self, file: Path) -> None:
        """Seed a to-be-created mod characters file from the same-named game /
        dependency file, if one exists.

        HOI4 loads ``common/characters`` per file: a mod file *replaces* the
        lower-layer file of the same name wholesale. Creating ``<TAG>.txt`` with
        just the new character would therefore silently delete every vanilla (or
        parent-mod) character of that country — so the mod copy starts as a full
        copy of the highest-priority lower-layer file and the new character is
        added on top of it."""
        for root, is_mod in reversed(self.ctx.override_layers(GAME_DIRS.CHARACTERS)):
            if is_mod:
                continue
            source = resolve_ci(root / GAME_DIRS.CHARACTERS / file.name)
            if source is not None and source.is_file():
                file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, file)
                return

    @staticmethod
    def _apply_role(character: Block, key: str, data: dict | None, builder) -> None:
        if data is None:
            character.remove(key)
        else:
            character.set(key, builder(data))

    @staticmethod
    def _traits_block(traits) -> Block:
        items = traits if isinstance(traits, (list, tuple)) else str(traits).split()
        return Block([Scalar(t) for t in items if t])

    def _build_country_leader(self, data: dict) -> Block:
        b = Block()
        b.add("ideology", Scalar(data.get("ideology", "despotism")))
        b.add("expire", Scalar(data.get("expire", "1965.1.1.1"), quoted=True))
        b.add("traits", self._traits_block(data.get("traits", [])))
        b.add("id", Scalar("-1"))
        return b

    def _build_advisor(self, data: dict) -> Block:
        b = Block()
        b.add("slot", Scalar(data.get("slot", "political_advisor")))
        b.add("idea_token", Scalar(data.get("idea_token") or "advisor"))
        if data.get("cost"):
            b.add("cost", Scalar(str(data["cost"])))
        b.add("traits", self._traits_block(data.get("traits", [])))
        return b

    def _build_general(self, data: dict) -> Block:
        b = Block()
        b.add("traits", self._traits_block(data.get("traits", [])))
        for key in ("skill", "attack_skill", "defense_skill", "planning_skill", "logistics_skill"):
            b.add(key, Scalar(str(data.get(key, 1))))
        return b

    def _build_navy_leader(self, data: dict) -> Block:
        b = Block()
        b.add("traits", self._traits_block(data.get("traits", [])))
        for key in ("skill", "attack_skill", "defense_skill", "maneuvering_skill", "coordination_skill"):
            b.add(key, Scalar(str(data.get(key, 1))))
        return b

    # --- deletion --------------------------------------------------------
    def delete(self, char_id: str) -> bool:
        """Remove a character from its mod file (and loc). Returns True if removed."""
        model = self.get(char_id)
        if model is None or not model.in_mod:
            return False
        file = self.characters_file(model.tag)
        if not file.exists():
            return False
        root = parse_file(file)
        chars = root.get_block("characters")
        if chars is None or not chars.has(char_id):
            return False
        chars.remove(char_id)
        if list(chars.pairs()):
            dump_file(root, file)
        else:
            file.unlink(missing_ok=True)
        loc_path = (self.ctx.mod.path / GAME_DIRS.LOCALISATION / "english"
                    / "anka_characters_l_english.yml")
        if loc_path.exists():
            loc = LocFile.load(loc_path)
            if char_id in loc:
                loc.remove(char_id).save(loc_path)
        # A deleted character must not stay recruited anywhere — dangling
        # ``recruit_character`` lines are a game error.
        self.remove_recruit_references(char_id)
        # Incremental cache update.
        if self._chars is not None:
            self._chars.pop(char_id, None)
        if self._names is not None:
            self._names.pop(char_id, None)
        return True

    def remove_recruit_references(self, char_id: str) -> list[str]:
        """Strip ``recruit_character = <char_id>`` lines from every editable
        (mod-side) country history file. Line-level text edit so untouched
        formatting/comments survive. Returns the relative files changed."""
        folder = self.ctx.mod.path / GAME_DIRS.HISTORY_COUNTRIES
        if not folder.is_dir():
            return []
        pattern = re.compile(
            rf"^[ \t]*recruit_character[ \t]*=[ \t]*{re.escape(char_id)}"
            rf"[ \t]*(#[^\r\n]*)?\r?\n",
            re.M)
        changed: list[str] = []
        for file in folder.glob("*.txt"):
            try:
                text = file.read_text(encoding="utf-8-sig", errors="ignore")
            except OSError:
                continue
            new_text = pattern.sub("", text)
            if new_text != text:
                file.write_text(new_text, encoding="utf-8")
                changed.append(f"{GAME_DIRS.HISTORY_COUNTRIES}/{file.name}")
        if changed and self._recruited is not None:
            self._recruited.pop(char_id, None)
        return changed

    # --- recruitment cache updates (called after CountryService writes) --
    def mark_recruited(self, char_id: str, tag: str) -> None:
        if self._recruited is not None:
            self._recruited.setdefault(char_id, [])
            if tag not in self._recruited[char_id]:
                self._recruited[char_id].append(tag)
        model = self._chars.get(char_id) if self._chars else None
        if model and tag not in model.recruited_by:
            model.recruited_by.append(tag)

    def mark_unrecruited(self, char_id: str, tag: str) -> None:
        if self._recruited is not None and char_id in self._recruited:
            self._recruited[char_id] = [t for t in self._recruited[char_id] if t != tag]
        model = self._chars.get(char_id) if self._chars else None
        if model and tag in model.recruited_by:
            model.recruited_by.remove(tag)
