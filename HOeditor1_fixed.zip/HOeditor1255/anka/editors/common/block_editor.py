"""Scratch-like recursive editor for PDX script blocks.

Renders a `Block` as nested visual rows: leaf ``key = value`` pairs become label +
entry, block pairs become bordered containers with their own children and their own
[+] button, and every level ends with a [+] that opens the block picker (logic
containers, the full effect/trigger catalog, or a free-form key). Values are edited
in place (writing straight into the PDX nodes); structural changes re-render.

``custom_effect_tooltip`` (scalar) and ``custom_trigger_tooltip`` (block with a
``tooltip`` key, per the HOI4 docs) get a third field on their loc-key row: the
localized tooltip text for the current language, saved through the owner's
loc protocol (collision-safe, per language). Game rules (``rule = { ... }``)
render as strict yes/no switches.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Callable

from ...core.pdx import Block, Pair, Scalar
from ...core.pdx import parse as pdx_parse
from ...ui.widgets.mousewheel import bind_wheel, unbind_wheel_all, wheel_steps
from ..effects import ScriptCatalog
from .dialogs import BaseDialog, SinglePickDialog

from collections import deque # stack

_OPS = ("=", "<", ">", "<=", ">=", "!=")

# Logic / flow containers offered by the picker, per script kind.
_CONTAINERS: dict[str, tuple[str, ...]] = {
    "trigger": ("AND", "OR", "NOT", "hidden_trigger"),
    "effect": ("if", "limit", "else", "random_list", "hidden_effect"),
}
_TOOLTIP_KEYS = ("custom_effect_tooltip", "custom_trigger_tooltip",
                 "custom_modifier_tooltip")

# Game rules (idea/character `rule = { ... }` blocks): fixed yes/no switches.
# Source: hoi4 wiki, Idea modding → game rules.
_RULE_PARENTS = ("rule",)
_GAME_RULES = (
    "can_access_market", "can_be_spymaster", "can_boost_other_ideologies",
    "can_boost_own_ideology", "can_create_collaboration_government",
    "can_create_factions", "can_declare_war_on_same_ideology",
    "can_declare_war_without_wargoal_when_in_war", "can_decline_call_to_war",
    "can_force_government", "can_generate_female_aces",
    "can_generate_female_country_leaders", "can_generate_female_unit_leaders",
    "can_guarantee_other_ideologies", "can_join_factions",
    "can_join_factions_not_allowed_diplomacy", "can_join_opposite_factions",
    "can_lower_tension", "can_not_build_buildings", "can_not_declare_war",
    "can_occupy_non_war", "can_only_justify_war_on_threat_country",
    "can_puppet", "can_send_volunteers", "can_use_kamikaze_pilots",
    "contributes_operatives", "units_deployed_to_overlord",
)

# ---------------------------------------------------------------------------
# Typed values: instead of free typing, known fields get a "…" picker button
# (searchable list of country tags, states by id+name, ideas, modifiers).
# ---------------------------------------------------------------------------
_KEY_TYPES = {                       # by parameter key inside blocks
    "tag": "country", "target": "country", "country": "country",
    "original_tag": "country", "exile": "country", "owner": "country",
    "controller": "country", "targeted_alliance": "country", "enemy": "country",
    "state": "state",
    "idea": "idea",
}
# Effects that fire an event: their ``id`` field (block form) and their scalar
# form (``country_event = ns.1``) both take an event id — picker offered.
_EVENT_EFFECT_KEYS = ("country_event", "news_event", "state_event",
                      "unit_leader_event", "operative_leader_event")
_VALUE_TYPES = {                     # by effect/trigger name in scalar form
    "country_event": "event", "news_event": "event", "state_event": "event",
    "unit_leader_event": "event", "operative_leader_event": "event",
    "country_exists": "country", "has_war_with": "country",
    "has_war_together_with": "country", "is_ally_with": "country",
    "is_puppet_of": "country", "is_subject_of": "country", "puppet": "country",
    "end_puppet": "country", "give_guarantee": "country", "add_to_faction": "country",
    "is_in_faction_with": "country", "is_neighbor_of": "country",
    "is_owned_by": "country", "is_controlled_by": "country", "is_core_of": "country",
    "is_claimed_by": "country", "white_peace": "country", "declare_war_on": "country",
    "has_defensive_war_with": "country", "has_offensive_war_with": "country",
    "has_wargoal_against": "country", "send_embargo": "country",
    "inherit_technology": "country",
    "set_cosmetic_tag": "cosmetic_tag", "has_cosmetic_tag": "cosmetic_tag",
    "owns_state": "state", "controls_state": "state", "add_state_core": "state",
    "add_state_claim": "state", "remove_state_core": "state",
    "remove_state_claim": "state", "transfer_state": "state", "set_capital": "state",
    "has_full_control_of_state": "state",
    "add_ideas": "idea", "remove_ideas": "idea", "has_idea": "idea",
    "show_ideas_tooltip": "idea",
    "complete_national_focus": "focus", "unlock_national_focus": "focus",
    "focus": "focus", "has_completed_focus": "focus",
    # start_border_war attacker/defender callbacks fire an event
    "on_win": "event", "on_lose": "event", "on_cancel": "event",
}
# Flag/variable effects & triggers whose scalar form names a flag; also handled in
# their block form (``… = { flag = X }``) by value_type_of via the parent key.
_COUNTRY_FLAG_KEYS = frozenset({
    "set_country_flag", "has_country_flag", "clr_country_flag",
    "modify_country_flag", "remove_country_flag"})
_GLOBAL_FLAG_KEYS = frozenset({
    "set_global_flag", "has_global_flag", "clr_global_flag", "modify_global_flag"})
_STATE_FLAG_KEYS = frozenset({
    "set_state_flag", "has_state_flag", "clr_state_flag", "modify_state_flag",
    "remove_state_flag"})
for _k in _COUNTRY_FLAG_KEYS:
    _VALUE_TYPES[_k] = "country_flag"
for _k in _GLOBAL_FLAG_KEYS:
    _VALUE_TYPES[_k] = "global_flag"
for _k in _STATE_FLAG_KEYS:
    _VALUE_TYPES[_k] = "state_flag"
_VAR_FLAG_TYPES = frozenset({"country_flag", "global_flag", "state_flag", "variable"})
_LIST_ITEM_TYPES = {                 # bare scalars inside ``<key> = { a b c }``
    "add_ideas": "idea", "remove_ideas": "idea", "show_ideas_tooltip": "idea",
    "prioritize": "state", "states": "state", "seller_tags": "country",
}
# Blocks whose child KEYS may be static modifiers (idea/state modifier blocks; the
# picker *adds* a modifiers section there rather than replacing effects/triggers).
_MODIFIER_PARENTS = ("modifier", "modifiers", "hidden_modifier", "targeted_modifier",
                     "state_modifier")


# Effects/triggers that must be a block with specific sub-keys — the game docs are
# terse and their catalog `example` is often empty, so a scalar fallback would be
# wrong. Inserted pre-filled with sensible defaults; `target` gets a country picker
# (see _KEY_TYPES). Keep these accurate to the HOI4 script API.
_BLOCK_TEMPLATES = {
    "declare_war_on": "declare_war_on = { target = FROM type = annex_everything }",
    "annex_country": "annex_country = { target = FROM transfer_troops = yes }",
    "create_wargoal": "create_wargoal = { type = annex_everything target = FROM }",
    "start_civil_war": ("start_civil_war = { ideology = communism "
                        "ruling_party = communism size = 0.5 }"),
    "become_exiled_in": "become_exiled_in = { target = FROM legitimacy = 50 }",
    # NB: puppet stays scalar by default (``puppet = TAG`` is idiomatic); the block
    # form is valid too but we don't force it.
    "set_autonomy": ("set_autonomy = { target = FROM "
                     "autonomy_state = autonomy_puppet freedom_level = 0.5 }"),
    "release_autonomy": ("release_autonomy = { target = FROM "
                         "autonomy_state = autonomy_puppet freedom_level = 0.5 }"),
    "diplomatic_relation": ("diplomatic_relation = { country = FROM "
                            "relation = military_access active = yes }"),
    "add_to_war": ("add_to_war = { targeted_alliance = FROM enemy = FROM "
                   "hostility_reason = asked_to_join }"),
    "add_opinion_modifier": ("add_opinion_modifier = { target = FROM "
                             "modifier = opinion_modifier_id }"),
    "remove_opinion_modifier": ("remove_opinion_modifier = { target = FROM "
                                "modifier = opinion_modifier_id }"),
    "set_politics": "set_politics = { ruling_party = communism elections_allowed = yes }",
    # STATE scope. `type` gets a picker over parsed common/buildings (mods add
    # their own buildings — never hardcode the list).
    "add_building_construction": ("add_building_construction = { "
                                  "type = industrial_complex level = 2 "
                                  "instant_build = yes }"),
    "add_dynamic_modifier": "add_dynamic_modifier = { modifier = my_dynamic_modifier }",
    "remove_dynamic_modifier": ("remove_dynamic_modifier = "
                                "{ modifier = my_dynamic_modifier }"),
    # trigger: divisions count, optionally of a given unit type. Inserts the
    # `size` comparison ready to edit; `type` is offered as a suggested field.
    "has_army_size": "has_army_size = { size < 40 }",
}

# Optional sub-keys offered as one-click buttons next to a block's [+]
# ("suggested fields"): (key, default value). Hidden once the key is present.
_BORDER_WAR_SIDE = (("num_provinces", "1"), ("on_win", ""), ("on_lose", ""),
                    ("on_cancel", ""), ("modifier", "0.5"),
                    ("dig_in_factor", "1.0"), ("terrain_factor", "1.0"))
_SUGGESTED_FIELDS: dict[str, tuple[tuple[str, str], ...]] = {
    "add_dynamic_modifier": (("days", "14"), ("scope", "ROOT")),
    # start_border_war [SHORT]: flesh out its skeleton one field at a time.
    "start_border_war": (("change_state_after_war", "no"), ("combat_width", "80"),
                         ("minimum_duration_in_days", "14")),
    "attacker": _BORDER_WAR_SIDE,
    "defender": _BORDER_WAR_SIDE,
    # has_army_size: the optional unit-type filter (armor / infantry / …).
    "has_army_size": (("type", "armor"),),
    # optional province targeting for provincial buildings (bunkers, naval bases…)
    "add_building_construction": (("province", "1234"),),
}

# Effects whose ``modifier`` field names a *dynamic* modifier (picker over
# common/dynamic_modifiers), and whose ``scope`` is a country.
_DYNAMIC_MODIFIER_EFFECTS = ("add_dynamic_modifier", "remove_dynamic_modifier",
                             "force_update_dynamic_modifier")


def _shared_value_options(ctx, vtype: str) -> list[tuple[str, str]]:
    """Central (display, value) lists so any script editor gets working pickers,
    even when its owner has no ``value_options`` for the type. Mirrors the
    per-editor implementations (focuses/decisions/…)."""
    if vtype == "country":
        from ...services.country_service import CountryService
        return [(f"{r.tag} · {r.name}", r.tag)
                for r in CountryService(ctx).list_tags(include_vanilla=True)]
    if vtype == "cosmetic_tag":
        from ...services.country_service import CountryService
        return [(r.tag, r.tag)
                for r in CountryService(ctx).list_cosmetic_tags(include_vanilla=True)]
    if vtype == "state":
        from ...services.state_service import StateService
        return [(f"{s.id} · {s.name}", str(s.id))
                for s in StateService(ctx).list_states()]
    if vtype == "idea":
        from ...services.idea_service import IdeaService
        return [(f"{i.id} · {i.category}", i.id)
                for i in IdeaService(ctx).list_ideas()]
    if vtype == "event":
        from ...services.event_service import EventService
        try:
            return EventService(ctx).event_options()
        except Exception:                                 # noqa: BLE001
            return []
    if vtype == "focus":
        from ...services.focus_service import FocusService
        try:
            return [(fid, fid) for fid in FocusService(ctx).focus_ids()]
        except Exception:                                 # noqa: BLE001
            return []
    if vtype == "modifier":
        return [(f"{n} · {', '.join(m.scopes)}" if m.scopes else n, n)
                for n, m in sorted(ScriptCatalog.modifiers().items())]
    if vtype == "building":
        from ...services.building_service import BuildingService
        return [(f"{b.name} · {b.scope}", b.name)
                for b in sorted(BuildingService(ctx).buildings().values(),
                                key=lambda b: b.name)]
    return []


def value_type_of(parent_key: str, key: str) -> str | None:
    if key == "id" and parent_key in _EVENT_EFFECT_KEYS:
        return "event"
    # `type` is heavily overloaded in HOI4 script — only the building effect's
    # one is a building name.
    if parent_key == "add_building_construction" and key == "type":
        return "building"
    if parent_key in _DYNAMIC_MODIFIER_EFFECTS:
        if key == "modifier":
            return "dynamic_modifier"
        if key == "scope":
            return "country"
    # block form: ``set_country_flag = { flag = X … }`` and friends
    if key == "flag":
        if parent_key in _COUNTRY_FLAG_KEYS:
            return "country_flag"
        if parent_key in _GLOBAL_FLAG_KEYS:
            return "global_flag"
        if parent_key in _STATE_FLAG_KEYS:
            return "state_flag"
    if key in ("var", "variable"):
        return "variable"
    return _KEY_TYPES.get(key) or _VALUE_TYPES.get(key)


# Scope-iterator / -quantifier keywords are always blocks — ``every_country = { … }``,
# ``any_owned_state = { … }`` — but the catalog ships no example for most, so without
# this they'd wrongly insert as a scalar leaf. Matched by the vanilla naming
# convention: ``every_``/``random_`` (+ ``global_`` variants) effects and ``any_``/
# ``all_`` triggers.
_SCOPE_EFFECT_PREFIXES = ("every_", "random_", "global_every_", "global_random_")
_SCOPE_TRIGGER_PREFIXES = ("any_", "all_")
# The lone ``any_``/``all_`` keyword that is a scalar comparison, not a scope block
# (``any_war_score > 0.5``), confirmed against vanilla usage.
_SCALAR_QUANTIFIERS = frozenset({"any_war_score"})


def _is_scope_iterator(item) -> bool:
    name = item.name
    kind = getattr(item, "kind", "")
    if kind == "effect" and name.startswith(_SCOPE_EFFECT_PREFIXES):
        return True
    if (kind == "trigger" and name.startswith(_SCOPE_TRIGGER_PREFIXES)
            and name not in _SCALAR_QUANTIFIERS):
        return True
    return False


def node_from_catalog(item) -> Pair:
    """Build an insertable Pair from a catalog entry — the documented example when it
    parses (instant pre-filled form), otherwise an empty ``name = `` leaf.

    List-form effects (``add_ideas = { a b }`` and friends) insert as an empty
    block; block-form effects (declare_war_on, annex_country, ...) insert a
    pre-filled skeleton so their required sub-keys (target/type) are present;
    scope-iterator effects (every_/random_) insert as an empty block."""
    if item.name in _LIST_ITEM_TYPES:
        return Pair(item.name, Block())
    template = _BLOCK_TEMPLATES.get(item.name)
    if template:
        try:
            root = pdx_parse(template, recover=False)
            for pair in root.pairs():
                if pair.key == item.name:
                    return pair
        except Exception:
            pass
    if item.example:
        try:
            root = pdx_parse(item.example, recover=False)
            for pair in root.pairs():
                if pair.key == item.name:
                    return pair
        except Exception:
            pass
    if _is_scope_iterator(item):
        return Pair(item.name, Block())
    return Pair(item.name, Scalar(""))


class BlockTreeEditor(ttk.Frame):
    def __init__(self, master, owner, root_block: Block, kinds: tuple[str, ...],
                 focus_id: str = "", root_key: str = "",
                 on_change: Callable[[], None] | None = None):
        super().__init__(master, style="Card.TFrame")
        self.owner = owner                    # FocusesEditor (service, loc_language, t)
        self.t = owner.t
        self.palette = owner.palette
        self.root_block = root_block
        self.kinds = kinds
        self.focus_id = focus_id
        self.root_key = root_key              # the script field being edited
        self._on_change = on_change or (lambda: None)
        self._shared_opts: dict[str, list[tuple[str, str]]] = {}

        self._hovered_stack = deque()
        # Rendering large scripts used to rebuild EVERY widget on any change and
        # could exceed Tk's ~32767px canvas-window height (rows past it silently
        # stopped rendering). Two mitigations: per-block partial re-render (the
        # registry maps a block to the frame holding its rows) and collapsible
        # containers (big subtrees start collapsed).
        self._registry: dict[int, tuple[ttk.Frame, int, str, tuple[str, ...]]] = {}
        self._expanded: set[int] = set()      # id(block) the user expanded
        self._collapsed: set[int] = set()     # id(block) the user collapsed
        self._row_budget = self._ROW_BUDGET   # rows left before force-collapsing
        self._render_epoch = 0                # cancels stale streamed renders

        self._canvas = tk.Canvas(self, bg=self.palette.surface, highlightthickness=0, bd=0)
        self._sb = ttk.Scrollbar(self, orient="vertical", command=self._canvas.yview)
        self._body = ttk.Frame(self._canvas, style="Card.TFrame")
        self._win = self._canvas.create_window((0, 0), window=self._body, anchor="nw")
        self._canvas.configure(yscrollcommand=self._sb.set)
        self._canvas.pack(side="left", fill="both", expand=True)
        self._sb.pack(side="right", fill="y")
        self._body.bind("<Configure>", lambda e: self._canvas.configure(
            scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>", lambda e: self._canvas.itemconfigure(
            self._win, width=e.width))
        self._canvas.bind("<Enter>", lambda e: bind_wheel(
            self._canvas, self._wheel, bind_all=True))
        self._canvas.bind("<Leave>", lambda e: unbind_wheel_all(self._canvas))
        self._canvas.bind("<Button-3>", lambda e: self._save_menu(e, None))
        self.render()

    def _wheel(self, event) -> None:
        steps = wheel_steps(event)
        if steps:
            self._canvas.yview_scroll(-steps, "units")

    # ------------------------------------------------------------------ render
    def render(self) -> None:
        """Streamed full render: the first ~30ms of rows paint synchronously so
        the editor appears instantly; the rest is appended in 30ms slices via
        ``after`` so a huge script never freezes the UI. A bumped epoch cancels
        an in-flight stream when a newer render starts."""
        y = self._canvas.yview()
        # Every box is about to be destroyed; drop the hover stack so a rebuild under
        # a stationary cursor can't re-highlight (or dim) an already-dead widget.
        self._hovered_stack.clear()
        self._registry.clear()
        self._row_budget = self._ROW_BUDGET
        self._render_epoch += 1
        epoch = self._render_epoch
        for w in self._body.winfo_children():
            w.destroy()
        self._registry[id(self.root_block)] = (self._body, 0, self.root_key,
                                               self.kinds)
        items = list(self.root_block.items)
        state = {"idx": 0}

        def pump() -> None:
            if epoch != self._render_epoch or not self._body.winfo_exists():
                return
            import time
            t0 = time.perf_counter()
            while (state["idx"] < len(items)
                   and time.perf_counter() - t0 < 0.03):
                self._render_item(self.root_block, items[state["idx"]],
                                  self._body, 0, self.root_key, self.kinds)
                state["idx"] += 1
            if state["idx"] < len(items):
                self.after(1, pump)
                return
            self._add_button(self.root_block, self._body, self.root_key, self.kinds)
            self._body.update_idletasks()
            self._canvas.yview_moveto(y[0])

        pump()

    def _rerender(self, block: Block) -> None:
        """Re-render only the frame holding `block`'s rows (structural edits used
        to rebuild the whole tree — seconds on large scripts). Falls back to a
        full render when the block isn't currently on screen."""
        if block is self.root_block:
            self.render()
            return
        entry = self._registry.get(id(block))
        if entry is None or not entry[0].winfo_exists():
            self.render()
            return
        frame, depth, parent_key, kinds = entry
        self._hovered_stack.clear()
        # Top up (never fully reset) the shared row budget: a root render may
        # still be streaming in the background and must keep its height cap.
        self._row_budget = max(self._row_budget, 150)
        for w in frame.winfo_children():
            w.destroy()
        self._render_block(block, frame, depth, parent_key, kinds)

    def _render_block(self, block: Block, parent: ttk.Frame, depth: int,
                      parent_key: str = "",
                      kinds: tuple[str, ...] | None = None) -> None:
        kinds = self.kinds if kinds is None else kinds
        self._registry[id(block)] = (parent, depth, parent_key, kinds)
        for item in list(block.items):
            self._render_item(block, item, parent, depth, parent_key, kinds)
        self._add_button(block, parent, parent_key, kinds)

    def _render_item(self, owner_block: Block, item, parent, depth: int,
                     parent_key: str = "",
                     kinds: tuple[str, ...] | None = None) -> None:
        kinds = self.kinds if kinds is None else kinds
        if isinstance(item, Pair) and isinstance(item.value, Block):
            self._render_container(owner_block, item, parent, depth, kinds)
        elif isinstance(item, Pair):
            self._render_leaf(owner_block, item, parent, parent_key, kinds)
        elif isinstance(item, Scalar):
            self._render_bare(owner_block, item, parent, parent_key)
        elif isinstance(item, Block):                 # rare: anonymous block
            self._render_container(owner_block, item, parent, depth, kinds)

    def _row(self, parent) -> ttk.Frame:
        self._row_budget -= 1
        row = ttk.Frame(parent, style="Card.TFrame")
        row.pack(fill="x", pady=1, anchor="w")
        return row

    # ------------------------------------------------------------ saved blocks
    def _bind_save_menu(self, widget, item) -> None:
        """Right-click on any row/container: save that node — or the whole edited
        content — into the personal snippet library (re-inserted later from the
        picker as a ``[BLOCK]`` entry)."""
        widget.bind("<Button-3>", lambda e: self._save_menu(e, item), add="+")

    def _save_menu(self, event, item) -> None:
        menu = tk.Menu(self, tearoff=0, bg=self.palette.surface,
                       fg=self.palette.text,
                       activebackground=self.palette.accent,
                       activeforeground=self.palette.accent_text, bd=0)
        if item is not None:
            menu.add_command(label="💾 " + self.t("focuses.blocks.save_block"),
                             command=lambda: self._save_snippet(item))
        menu.add_command(label="💾 " + self.t("focuses.blocks.save_all"),
                         command=lambda: self._save_snippet(None))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    def _save_snippet(self, item) -> None:
        from ...core.pdx import dumps
        if item is None:                      # whole edited content
            text = dumps(self.root_block, top_level=True)
            initial = self.root_key or "my_block"
        elif isinstance(item, Pair):
            text = dumps(Block([item]), top_level=True)
            initial = item.key
        else:                                 # bare Scalar / anonymous Block
            text = dumps(Block([item]), top_level=True)
            initial = "my_block"
        if not text.strip():
            return
        from .dialogs import TextPromptDialog
        from ...services import saved_blocks

        def submit(name: str) -> None:
            saved_blocks.add(name, text)

        TextPromptDialog(self, self.owner, self.t("focuses.blocks.save_block"),
                         self.t("focuses.blocks.saved_name"), submit,
                         initial=initial, pattern=r"^.+$")

    def _del_btn(self, row, owner_block: Block, item) -> None:
        ttk.Button(row, text="✕", width=2,
                   command=lambda: self._remove(owner_block, item)).pack(side="right", padx=2)

    def _remove(self, owner_block: Block, item) -> None:
        if item in owner_block.items:
            owner_block.items.remove(item)
        self._rerender(owner_block)
        self._on_change()

    def _key_widget(self, row, pair: Pair) -> None:
        """Known keywords render as labels; unknown keys stay editable."""
        known = (ScriptCatalog.find(pair.key) is not None
                 or pair.key in ScriptCatalog.modifiers()
                 or pair.key in _GAME_RULES
                 or pair.key in _CONTAINERS["trigger"] + _CONTAINERS["effect"]
                 or pair.key in _TOOLTIP_KEYS
                 or pair.key in ("limit", "else_if", "tooltip", "factor", "add",
                                 "base", "modifier", "rule"))
        if known:
            ttk.Label(row, text=pair.key, style="Card.TLabel").pack(side="left")
        else:
            var = tk.StringVar(value=pair.key)
            entry = ttk.Entry(row, textvariable=var, width=max(8, len(pair.key) + 2))
            entry.pack(side="left")
            var.trace_add("write", lambda *_: (setattr(pair, "key", var.get().strip()),
                                               self._on_change()))

    def _op_editable(self, pair: Pair, kinds: tuple[str, ...]) -> bool:
        """Whether this leaf may use comparison operators. Only triggers can:
        effects, static modifiers and game rules are always plain
        ``key = value`` assignments.

        * Effect-only context  -> never editable.
        * Modifier / rule keys -> never editable, wherever they appear.
        * Trigger-only context -> editable (e.g. inside ``limit``).
        * Mixed context        -> decide per key: triggers (and unknown keys,
          which may be scripted-variable comparisons) are editable.
        """
        if "trigger" not in kinds:
            return False
        if pair.key in ScriptCatalog.modifiers() or pair.key in _GAME_RULES \
                or pair.key == "tooltip":
            return False
        if kinds == ("trigger",):
            return True
        item = ScriptCatalog.find(pair.key)
        return item is None or item.kind != "effect"

    def _render_leaf(self, owner_block: Block, pair: Pair, parent,
                     parent_key: str = "",
                     kinds: tuple[str, ...] | None = None) -> None:
        kinds = self.kinds if kinds is None else kinds
        row = self._row(parent)
        self._bind_save_menu(row, pair)
        self._key_widget(row, pair)

        # Comparison operators (<, >, <=, >=, !=) are only meaningful for triggers.
        # Effects are always plain assignments, so their operator is a fixed "="
        # label the user cannot change (see hoi4 wiki: Triggers vs Effects).
        if self._op_editable(pair, kinds):
            op_var = tk.StringVar(value=pair.op)
            op = ttk.Combobox(row, textvariable=op_var, values=_OPS, width=3,
                              state="readonly")
            op.pack(side="left", padx=3)
            op_var.trace_add("write", lambda *_: (setattr(pair, "op", op_var.get()),
                                                  self._on_change()))
        else:
            if pair.op != "=":
                pair.op = "="          # normalise any stray operator on an effect
            ttk.Label(row, text="=", style="Card.TLabel").pack(side="left", padx=3)

        scalar = pair.value
        val_var = tk.StringVar(value=scalar.raw)
        is_rule = (pair.key in _GAME_RULES or parent_key in _RULE_PARENTS)
        if is_rule:
            # game rules are strict yes/no switches
            box = ttk.Combobox(row, textvariable=val_var, width=5,
                               state="readonly", values=("yes", "no"))
            box.pack(side="left")
        else:
            entry = ttk.Entry(row, textvariable=val_var, width=24)
            entry.pack(side="left")

        def value_changed(*_a) -> None:
            text = val_var.get()
            scalar.raw = text
            scalar.quoted = scalar.quoted or (" " in text)
            self._on_change()
        val_var.trace_add("write", value_changed)

        vtype = value_type_of(parent_key, pair.key)
        if vtype is not None and not is_rule:
            self._picker_button(row, vtype, val_var)
        if pair.key in _TOOLTIP_KEYS or (pair.key == "tooltip"
                                         and parent_key == "custom_trigger_tooltip"):
            self._tooltip_loc_field(row, val_var)
        self._del_btn(row, owner_block, pair)

    def _picker_button(self, row, vtype: str, val_var: tk.StringVar) -> None:
        """The '…' button next to typed values: searchable pick list instead of
        hand-typing tags / state ids / idea ids / modifier names."""
        def open_picker() -> None:
            SinglePickDialog(self, self.owner, self.t(f"focuses.pick.{vtype}"),
                             self._resolve_options(vtype),
                             lambda value: val_var.set(value),
                             current=val_var.get().strip())
        ttk.Button(row, text="…", width=2, command=open_picker).pack(side="left", padx=2)

    def _resolve_options(self, vtype: str) -> list[tuple[str, str]]:
        """Options for a typed-value picker. dynamic_modifier / flags / variables
        are resolved centrally so every script editor gets them; the owner
        (focuses/decisions/…) supplies the rest. When an owner offers no options
        for a type — e.g. the scripted-GUI script editor, whose owner returns []
        — fall back to the shared services so pickers like owns_state's state
        list still work everywhere (cached per editor instance)."""
        ctx = getattr(self.owner, "context", None)
        if vtype == "dynamic_modifier":
            from ...services.dynamic_modifier_service import \
                DynamicModifierService
            return DynamicModifierService.options(ctx)
        if vtype in _VAR_FLAG_TYPES:
            from ...services.script_vars_service import ScriptVarsService
            return ScriptVarsService(ctx).options(vtype)
        options = self.owner.value_options(vtype)
        if options or ctx is None:
            return options
        if vtype not in self._shared_opts:
            self._shared_opts[vtype] = _shared_value_options(ctx, vtype)
        return self._shared_opts[vtype]

    def _tooltip_loc_field(self, row, key_var: tk.StringVar) -> None:
        """Extra field on custom_*_tooltip rows: the localized text behind the key.
        Reads/writes through the owner's `loc_get`/`loc_set` protocol methods."""
        lang = self.owner.loc_language
        ttk.Label(row, text="📝", style="CardMuted.TLabel").pack(side="left", padx=(8, 2))
        text_var = tk.StringVar()
        entry = ttk.Entry(row, textvariable=text_var, width=30)
        entry.pack(side="left")

        loading = {"on": False}

        def load(*_a) -> None:
            loading["on"] = True
            key = key_var.get().strip()
            text_var.set(self.owner.loc_get(key, lang) if key else "")
            loading["on"] = False

        job: list = [None]

        def save() -> None:
            job[0] = None
            key = key_var.get().strip()
            text = text_var.get().strip()
            if key and text:
                self.owner.loc_set(key, lang, text)

        def schedule(*_a) -> None:
            if loading["on"]:
                return
            if job[0] is not None:
                entry.after_cancel(job[0])
            job[0] = entry.after(900, save)

        load()
        text_var.trace_add("write", schedule)
        entry.bind("<FocusOut>", lambda e: save())
        key_var.trace_add("write", load)

    def _render_bare(self, owner_block: Block, scalar: Scalar, parent,
                     parent_key: str = "") -> None:
        row = self._row(parent)
        self._bind_save_menu(row, scalar)
        var = tk.StringVar(value=scalar.raw)
        ttk.Entry(row, textvariable=var, width=20).pack(side="left")
        var.trace_add("write", lambda *_: (setattr(scalar, "raw", var.get()),
                                           self._on_change()))
        vtype = _LIST_ITEM_TYPES.get(parent_key)
        if vtype is not None:
            self._picker_button(row, vtype, var)
        self._del_btn(row, owner_block, scalar)

    # Auto-collapse thresholds: a nested container whose subtree holds this many
    # items (or any top-level one above the larger bound) starts collapsed. The
    # row budget caps a single render pass regardless of structure — beyond it
    # every further container renders collapsed, keeping the widget count AND
    # the total pixel height below Tk's ~32767px canvas-window limit.
    _COLLAPSE_NESTED = 25
    _COLLAPSE_TOP = 80
    _ROW_BUDGET = 300

    def _subtree_size(self, block: Block, cap: int = 200) -> int:
        """Number of items in a block, recursive, early-exited at `cap`."""
        total = 0
        stack = [block]
        while stack and total < cap:
            for it in stack.pop().items:
                total += 1
                value = it.value if isinstance(it, Pair) else it
                if isinstance(value, Block):
                    stack.append(value)
        return total

    def _is_collapsed(self, block: Block, depth: int) -> bool:
        bid = id(block)
        if bid in self._expanded:
            return False
        if bid in self._collapsed:
            return True
        if not block.items:
            return False
        if self._row_budget <= 0:
            return True
        size = self._subtree_size(block)
        return size >= (self._COLLAPSE_NESTED if depth >= 1 else self._COLLAPSE_TOP)

    def _toggle_collapse(self, block: Block, owner_block: Block, depth: int) -> None:
        bid = id(block)
        if self._is_collapsed(block, depth):
            self._collapsed.discard(bid)
            self._expanded.add(bid)
        else:
            self._expanded.discard(bid)
            self._collapsed.add(bid)
        self._rerender(owner_block)

    def _render_container(self, owner_block: Block, item, parent, depth: int,
                          kinds: tuple[str, ...] | None = None) -> None:
        kinds = self.kinds if kinds is None else kinds
        pair = item if isinstance(item, Pair) else None
        block = item.value if pair is not None else item
        collapsed = self._is_collapsed(block, depth)
        self._row_budget -= 1                 # the container head counts as a row
        box = tk.Frame(parent, bg=self.palette.surface,
                       highlightbackground=self.palette.border,
                       highlightcolor=self.palette.border, highlightthickness=1)
        box.pack(fill="x", pady=2, padx=(depth and 0, 0), anchor="w")
        self._add_hover(box)
        self._bind_save_menu(box, item)
        head = ttk.Frame(box, style="Card.TFrame")
        head.pack(fill="x", padx=4, pady=(3, 0))
        self._bind_save_menu(head, item)
        if block.items:
            ttk.Button(head, text="▸" if collapsed else "▾", width=2,
                       command=lambda: self._toggle_collapse(block, owner_block, depth)
                       ).pack(side="left", padx=(0, 3))
        if pair is not None:
            self._key_widget(head, pair)
            ttk.Label(head, text="= {", style="CardMuted.TLabel").pack(side="left", padx=4)
        if collapsed:
            ttk.Label(head, text="…  " + self.t("focuses.script.hidden_items",
                                                count=self._subtree_size(block)) + "  }",
                      style="CardMuted.TLabel").pack(side="left", padx=4)
        ttk.Button(head, text="✕", width=2,
                   command=lambda: self._remove(owner_block, item)).pack(side="right", padx=2)
        if collapsed:
            return
        body = ttk.Frame(box, style="Card.TFrame")
        body.pack(fill="x", padx=(18, 4), pady=(0, 4))
        self._render_block(block, body, depth + 1,
                           parent_key=pair.key if pair is not None else "",
                           kinds=self._child_kinds(pair, kinds))

    def _child_kinds(self, pair: Pair | None, kinds: tuple[str, ...]) -> tuple[str, ...]:
        """Narrow the allowed script kinds when descending into a known container, so
        the operator rule (triggers only) reaches parameter sub-keys the catalog does
        not list on their own (``type``, ``ideology``, ``instant_build`` …).

        A ``limit`` / logic-trigger block holds trigger conditions only — never
        effects — even inside an effect script; a known effect/trigger keyword forces
        its whole subtree to that kind. Unknown containers keep the parent's kinds.
        """
        if pair is None:
            return kinds
        key = pair.key
        if key == "limit" or key in _CONTAINERS["trigger"]:
            return ("trigger",)
        if key in _CONTAINERS["effect"]:
            return ("effect",)
        item = ScriptCatalog.find(key)
        if item is not None and item.kind in ("effect", "trigger"):
            return (item.kind,)
        return kinds

    def _add_hover(self, box: tk.Frame) -> None:
        """Highlight only the innermost container under the pointer (accent border, a
        touch thicker). A stack tracks the nesting so leaving a child restores its
        parent's highlight; `render()` clears the stack when boxes are destroyed."""
        def enter(_e=None) -> None:
            if self._hovered_stack:
                self._set_border(self._hovered_stack[-1], hot=False)
            self._hovered_stack.append(box)
            self._set_border(box, hot=True)

        def leave(_e=None) -> None:
            # Unwind to (and including) this box: children entered after it may have
            # already been popped, so guard against it no longer being on the stack.
            if box in self._hovered_stack:
                while self._hovered_stack:
                    if self._set_border(self._hovered_stack.pop(), hot=False) is box:
                        break
            if self._hovered_stack:
                self._set_border(self._hovered_stack[-1], hot=True)

        box.bind("<Enter>", enter, add="+")
        box.bind("<Leave>", leave, add="+")

    def _set_border(self, box: tk.Frame, *, hot: bool) -> tk.Frame:
        """Colour a box's border, tolerating boxes destroyed by a re-render."""
        if box.winfo_exists():
            colour = self.palette.accent if hot else self.palette.border
            box.configure(highlightbackground=colour, highlightcolor=colour,
                          highlightthickness=2 if hot else 1)
        return box

    def _add_button(self, block: Block, parent, parent_key: str = "",
                    kinds: tuple[str, ...] | None = None) -> None:
        kinds = self.kinds if kinds is None else kinds
        row = ttk.Frame(parent, style="Card.TFrame")
        row.pack(fill="x", pady=1, anchor="w")
        # Suggested optional sub-keys (e.g. days / scope on add_dynamic_modifier):
        # one click inserts the field pre-filled; hidden once present.
        for key, default in _SUGGESTED_FIELDS.get(parent_key, ()):
            if not block.has(key):
                ttk.Button(row, text=f"➕ {key}", width=len(key) + 3,
                           command=lambda k=key, d=default: self._add_suggested(
                               block, k, d)).pack(side="left", padx=(0, 4))
        ttk.Button(row, text="➕", width=3,
                   command=lambda: self._pick_new(block, parent_key, kinds)).pack(side="left")
        # Inside a list-form effect (add_ideas = { a b }, prioritize = {...}, ...)
        # offer a one-click "add item" that appends a bare value with a picker.
        list_type = _LIST_ITEM_TYPES.get(parent_key)
        if list_type is not None:
            ttk.Button(row, text="➕ " + self.t(f"focuses.pick.{list_type}"),
                       command=lambda: self._add_bare(block)).pack(side="left", padx=4)

    def _add_suggested(self, block: Block, key: str, default: str) -> None:
        block.items.append(Pair(key, Scalar(default)))
        self._rerender(block)
        self._on_change()

    def _add_bare(self, block: Block) -> None:
        block.items.append(Scalar(""))
        self._rerender(block)
        self._on_change()

    # ------------------------------------------------------------------ picker
    def _pick_new(self, block: Block, parent_key: str = "",
                  kinds: tuple[str, ...] | None = None) -> None:
        BlockPickerDialog(self, self.owner, self.kinds if kinds is None else kinds,
                          lambda node: self._insert(block, node),
                          with_modifiers=parent_key in _MODIFIER_PARENTS,
                          with_rules=parent_key in _RULE_PARENTS)

    def _insert(self, block: Block, node) -> None:
        # a saved [BLOCK] snippet may carry several top-level items
        block.items.extend(node if isinstance(node, list) else [node])
        self._rerender(block)
        self._on_change()


class BlockPickerDialog(BaseDialog):
    """Searchable picker: logic containers, special blocks, the effect/trigger
    catalog and free-form entries. Returns a ready PDX node via `on_pick`."""

    def __init__(self, master, editor, kinds: tuple[str, ...],
                 on_pick: Callable[[object], None], with_modifiers: bool = False,
                 with_rules: bool = False):
        super().__init__(master, editor, editor.t("focuses.blocks.add"), (520, 540))
        self._kinds = kinds
        self._on_pick = on_pick
        self._with_modifiers = with_modifiers
        self._with_rules = with_rules

        body = ttk.Frame(self, style="Card.TFrame", padding=12)
        body.pack(fill="both", expand=True, padx=12, pady=12)
        body.rowconfigure(1, weight=3)
        body.rowconfigure(2, weight=2)
        body.columnconfigure(0, weight=1)

        self._query = tk.StringVar()
        self._query.trace_add("write", lambda *_: self._refresh())
        entry = ttk.Entry(body, textvariable=self._query)
        entry.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        entry.focus_set()
        entry.bind("<Return>", lambda e: self._submit())

        self._list = tk.Listbox(body, bg=self.palette.surface_alt, fg=self.palette.text,
                                relief="flat", selectbackground=self.palette.accent,
                                font=("Consolas", 10), exportselection=False)
        self._list.grid(row=1, column=0, sticky="nsew")
        sb = ttk.Scrollbar(body, orient="vertical", command=self._list.yview)
        sb.grid(row=1, column=1, sticky="ns")
        self._list.configure(yscrollcommand=sb.set)
        self._list.bind("<Double-1>", lambda e: self._submit())
        self._list.bind("<<ListboxSelect>>", self._show_doc)
        self._list.bind("<Button-3>", self._saved_context)

        self._doc = tk.Text(body, height=7, wrap="word", state="disabled",
                            bg=self.palette.surface, fg=self.palette.text_muted,
                            relief="flat", font=("Consolas", 9))
        self._doc.grid(row=2, column=0, columnspan=2, sticky="nsew", pady=(6, 0))

        btns = ttk.Frame(body, style="Card.TFrame")
        btns.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Button(btns, text=self.t("common.cancel"),
                   command=self.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text=self.t("common.add"), style="Accent.TButton",
                   command=self._submit).pack(side="right")

        self._entries: list[tuple[str, object]] = []
        self._refresh()

    # entry payloads: ("container", key) | ("tooltip", key) | ("catalog", item)
    #                 | ("custom_leaf", None) | ("custom_block", None)
    def _refresh(self) -> None:
        q = self._query.get().strip().lower()
        t = self.t
        entries: list[tuple[str, object]] = []
        for kind in ("trigger", "effect"):
            if kind not in self._kinds:
                continue
            for key in _CONTAINERS[kind]:
                if not q or q in key.lower():
                    entries.append((f"{{}}  {key}", ("container", key)))
        if "effect" in self._kinds and (not q or q in "custom_effect_tooltip"):
            entries.append(("📝  custom_effect_tooltip", ("tooltip", "custom_effect_tooltip")))
        if "trigger" in self._kinds and (not q or q in "custom_trigger_tooltip"):
            entries.append(("📝  custom_trigger_tooltip", ("tooltip", "custom_trigger_tooltip")))
        if (self._with_modifiers or "modifier" in self._kinds) \
                and (not q or q in "custom_modifier_tooltip"):
            entries.append(("📝  custom_modifier_tooltip",
                            ("tooltip", "custom_modifier_tooltip")))
        entries.append(("✏  " + t("focuses.blocks.custom_leaf"), ("custom_leaf", None)))
        entries.append(("✏  " + t("focuses.blocks.custom_block"), ("custom_block", None)))
        # personal snippet library — distinguished by the [BLOCK] prefix
        from ...services import saved_blocks
        for saved in saved_blocks.all_blocks():
            if not q or q in saved["name"].lower():
                entries.append((f"[BLOCK] {saved['name']}", ("saved", saved)))
        if self._with_rules:
            for rule in _GAME_RULES:
                if not q or q in rule:
                    entries.append((f"📏  {rule}", ("rule", rule)))
        badge = {"effect": "⚡", "trigger": "❔", "modifier": "📊"}
        kinds = (("modifier",) if self._with_modifiers else ()) + tuple(self._kinds)
        for kind in kinds:
            for item in ScriptCatalog.search(q, kind)[:250]:
                entries.append((f"{badge[kind]} {item.title}", ("catalog", item)))
        self._entries = entries
        self._list.delete(0, "end")
        for label, _p in entries:
            self._list.insert("end", label)

    def _selected(self):
        sel = self._list.curselection()
        return self._entries[sel[0]][1] if sel else None

    def _saved_context(self, event) -> None:
        """Right-click on a ``[BLOCK]`` entry: offer deleting it from the library."""
        index = self._list.nearest(event.y)
        if not (0 <= index < len(self._entries)):
            return
        kind, data = self._entries[index][1]
        if kind != "saved":
            return
        self._list.selection_clear(0, "end")
        self._list.selection_set(index)
        menu = tk.Menu(self, tearoff=0, bg=self.palette.surface,
                       fg=self.palette.text,
                       activebackground=self.palette.accent,
                       activeforeground=self.palette.accent_text, bd=0)

        def delete() -> None:
            from ...services import saved_blocks
            saved_blocks.remove(data["name"])
            self._refresh()

        menu.add_command(label="🗑 " + self.t("focuses.blocks.delete_saved"),
                         command=delete)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _show_doc(self, _event=None) -> None:
        payload = self._selected()
        self._doc.configure(state="normal")
        self._doc.delete("1.0", "end")
        if payload and payload[0] == "saved":
            self._doc.insert("1.0", payload[1]["text"])
        elif payload and payload[0] == "catalog":
            item = payload[1]
            parts = [item.title]
            if item.scopes:
                parts.append(f"{self.t('focuses.script.scope')}: {', '.join(item.scopes)}")
            if item.description:
                parts.append("")
                parts.append(item.description)
            if item.example:
                parts.append("")
                parts.append(item.example)
            self._doc.insert("1.0", "\n".join(parts))
        self._doc.configure(state="disabled")

    def _submit(self) -> None:
        payload = self._selected()
        if payload is None:
            # allow typing a raw key and pressing Enter with nothing selected
            text = self._query.get().strip()
            if text.replace("_", "").isalnum():
                payload = ("typed", text)
            else:
                return
        kind, data = payload
        typed = self._query.get().strip()
        if kind == "container":
            # `if` (and else_if) is meaningless without a `limit` holding the
            # conditions — pre-create it so the structure is always valid.
            inner = (Block([Pair("limit", Block())])
                     if data in ("if", "else_if") else Block())
            node = Pair(data, inner)
        elif kind == "tooltip":
            master = self.master
            fid = getattr(master, "focus_id", "") or "my_focus"
            if data == "custom_trigger_tooltip":
                # block form per the HOI4 docs: the loc key sits in `tooltip`
                node = Pair(data, Block([Pair("tooltip", Scalar(f"{fid}_tt"))]))
            else:
                node = Pair(data, Scalar(f"{fid}_tt"))
        elif kind == "rule":
            node = Pair(data, Scalar("yes"))
        elif kind == "saved":
            try:
                parsed = pdx_parse(data["text"], recover=False)
            except Exception:
                return
            if not parsed.items:
                return
            node = list(parsed.items)
        elif kind == "catalog":
            node = node_from_catalog(data)
        elif kind == "custom_block":
            node = Pair(typed if typed.replace("_", "").isalnum() else "key", Block())
        else:  # custom_leaf / typed
            key = data if kind == "typed" else (
                typed if typed.replace("_", "").isalnum() else "key")
            node = Pair(key, Scalar(""))
        self.destroy()
        self._on_pick(node)
