"""Lightweight cache layer used across the app.

Two things are cached, for the same reason: decoding/converting HOI4 image
assets (TGA/DDS <-> PNG) is one of the slowest things this app does, and the
same files get re-read constantly (tree panels, canvases, inspectors all
redraw the same icons on every selection change).

* ``memory_cache`` — an in-process LRU used for hot, short-lived lookups
  (mainly decoded ``PIL.Image`` objects and ``ImageTk.PhotoImage`` handles
  that must not be garbage-collected while a widget still references them).
* ``DiskCache`` — a small on-disk cache (under the app's writable root) for
  anything worth persisting across restarts, keyed by a hash of the source
  file's path + modification time, so a changed source file is automatically
  treated as a cache miss.

Both are exposed through a single ``CACHE`` singleton so the rest of the app
(and the Settings screen's "Clear cache" button) has one place to go.
"""
from __future__ import annotations

import functools
import hashlib
import shutil
import time
from pathlib import Path
from typing import Callable, TypeVar

from ..config.constants import Paths

T = TypeVar("T")

_MEMORY_CACHE_MAX = 512


def _key_for(path: Path) -> str:
    try:
        stat = path.stat()
        raw = f"{path.resolve()}::{stat.st_mtime_ns}::{stat.st_size}"
    except OSError:
        raw = str(path)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


class _LRU:
    """Minimal insertion-ordered LRU on top of a plain dict — no external deps."""

    def __init__(self, maxsize: int):
        self._maxsize = maxsize
        self._data: dict[str, object] = {}

    def get(self, key: str):
        if key not in self._data:
            return None
        value = self._data.pop(key)
        self._data[key] = value  # move to the end (most-recently-used)
        return value

    def set(self, key: str, value: object) -> None:
        if key in self._data:
            self._data.pop(key)
        elif len(self._data) >= self._maxsize:
            self._data.pop(next(iter(self._data)))  # evict oldest
        self._data[key] = value

    def clear(self) -> None:
        self._data.clear()

    def __len__(self) -> int:
        return len(self._data)


class DiskCache:
    """Content-addressed cache of converted/generated image bytes on disk."""

    def __init__(self, subdir: str = "cache"):
        self.root = Paths.ROOT / subdir

    def _ensure(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)

    def path_for(self, source: str | Path, suffix: str = ".png") -> Path:
        self._ensure()
        return self.root / f"{_key_for(Path(source))}{suffix}"

    def get(self, source: str | Path, suffix: str = ".png") -> Path | None:
        p = self.path_for(source, suffix)
        return p if p.exists() else None

    def size_bytes(self) -> int:
        if not self.root.exists():
            return 0
        return sum(f.stat().st_size for f in self.root.rglob("*") if f.is_file())

    def file_count(self) -> int:
        if not self.root.exists():
            return 0
        return sum(1 for f in self.root.rglob("*") if f.is_file())

    def clear(self) -> None:
        if self.root.exists():
            shutil.rmtree(self.root, ignore_errors=True)
        self._ensure()


class CacheManager:
    """Single entry point: in-memory LRU + on-disk cache + basic stats."""

    def __init__(self):
        self.memory = _LRU(_MEMORY_CACHE_MAX)
        self.disk = DiskCache()
        self._hits = 0
        self._misses = 0

    # --- generic memoized-load helper ------------------------------------
    def cached_load(self, path: str | Path, loader: Callable[[], T]) -> T:
        """Return ``loader()``'s result, memoized in RAM for this file's
        current (path, mtime, size). Used for decoded PIL/Tk images that are
        cheap to keep around but expensive to reproduce."""
        key = _key_for(Path(path))
        hit = self.memory.get(key)
        if hit is not None:
            self._hits += 1
            return hit  # type: ignore[return-value]
        self._misses += 1
        value = loader()
        self.memory.set(key, value)
        return value

    @property
    def stats(self) -> dict:
        total = self._hits + self._misses
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": (self._hits / total) if total else 0.0,
            "memory_entries": len(self.memory),
            "disk_files": self.disk.file_count(),
            "disk_bytes": self.disk.size_bytes(),
        }

    def clear(self) -> None:
        """Wipe both cache layers. Safe to call any time — the next access
        simply re-decodes/re-converts from the source files on disk."""
        self.memory.clear()
        self.disk.clear()
        self._hits = 0
        self._misses = 0


CACHE = CacheManager()


def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"
