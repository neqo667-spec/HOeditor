"""A quiet, non-distracting starfield backdrop for the "galactic" theme.

``Starfield`` is a plain ``tk.Canvas`` that paints a vertical space-gradient,
a couple of soft nebula blobs, and a scatter of static stars. It is meant to
sit *behind* a screen's real content (packed/placed first, with everything
else laid on top via ``place`` so the stars show through the gaps), not to
replace any widget. It redraws itself on resize but the star positions are
fixed once generated, so text stays perfectly readable and nothing steals
attention while the user is working.
"""
from __future__ import annotations

import random
import tkinter as tk


def _lerp_hex(c1: str, c2: str, t: float) -> str:
    """Blend two ``#rrggbb`` colors; t=0 -> c1, t=1 -> c2."""
    r1, g1, b1 = int(c1[1:3], 16), int(c1[3:5], 16), int(c1[5:7], 16)
    r2, g2, b2 = int(c2[1:3], 16), int(c2[3:5], 16), int(c2[5:7], 16)
    r = int(r1 + (r2 - r1) * t)
    g = int(g1 + (g2 - g1) * t)
    b = int(b1 + (b2 - b1) * t)
    return f"#{r:02x}{g:02x}{b:02x}"


class Starfield(tk.Canvas):
    """Static starfield + nebula backdrop, restyled per-palette via ``repaint``."""

    def __init__(self, master, palette, star_count: int = 140, seed: int = 7):
        super().__init__(master, highlightthickness=0, bd=0)
        self._palette = palette
        self._star_count = star_count
        self._rng = random.Random(seed)
        # (relx, rely, radius, brightness 0-1) — generated once, reused across
        # resizes/repaints so the sky doesn't "reshuffle" while the user works.
        self._stars = [
            (self._rng.random(), self._rng.random(),
             self._rng.uniform(0.6, 1.8), self._rng.uniform(0.35, 1.0))
            for _ in range(star_count)
        ]
        self.bind("<Configure>", lambda _e: self._redraw())

    def set_palette(self, palette) -> None:
        self._palette = palette
        self._redraw()

    # -- internals ----------------------------------------------------
    def _redraw(self) -> None:
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w <= 1 or h <= 1:
            return

        p = self._palette
        if p.is_dark:
            top, bottom = "#050414", p.bg
            nebula = (p.accent, "#2a1f52")
            star_color = "#ffffff"
        else:
            # Light theme keeps a subtle daytime-nebula wash instead of stars,
            # so the UI stays bright and readable.
            top, bottom = "#dfe3fb", p.bg
            nebula = (p.accent, "#c9cdf0")
            star_color = "#ffffff"

        self.configure(bg=p.bg)

        # Vertical gradient background (banded rectangles; cheap and smooth
        # enough at typical window heights).
        top_hex = top if top.startswith("#") and len(top) == 7 else p.bg
        bands = 48
        for i in range(bands):
            t = i / bands
            color = _lerp_hex(top_hex, p.bg, t)
            y0 = int(h * t)
            y1 = int(h * (t + 1 / bands)) + 1
            self.create_rectangle(0, y0, w, y1, fill=color, outline="")

        # Soft nebula glows (a few overlapping translucent-looking blobs,
        # approximated with concentric stippled ovals since tk has no alpha).
        self._draw_nebula(w * 0.15, h * 0.22, min(w, h) * 0.45, nebula[0])
        self._draw_nebula(w * 0.85, h * 0.75, min(w, h) * 0.35, nebula[1])

        if p.is_dark:
            for relx, rely, r, brightness in self._stars:
                x, y = relx * w, rely * h
                size = r * (1.0 + brightness * 0.4)
                self.create_oval(x - size, y - size, x + size, y + size,
                                  fill=star_color, outline="",
                                  stipple="gray50" if brightness < 0.6 else "")

    def _draw_nebula(self, cx: float, cy: float, radius: float, color: str) -> None:
        steps = 6
        for i in range(steps, 0, -1):
            r = radius * (i / steps)
            stipple = ("gray12", "gray25")[i % 2]
            self.create_oval(cx - r, cy - r, cx + r, cy + r,
                              fill=color, outline="", stipple=stipple)
