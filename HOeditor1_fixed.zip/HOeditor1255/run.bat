@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

title HOeditor - HOI4 Mod Editor

echo ===============================================
echo   HOeditor - HOI4 Mod Editor - Launcher
echo ===============================================
echo.

REM --- Check that Python is installed and in PATH ---
where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found in PATH.
    echo Please install Python 3.10+ from https://www.python.org/downloads/
    echo and make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

REM --- Create virtual environment if it does not exist yet ---
if not exist "venv\Scripts\python.exe" (
    echo [*] Virtual environment not found. Creating venv...
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
)

REM --- Activate venv ---
call "venv\Scripts\activate.bat"

REM --- Install / update dependencies ---
echo [*] Checking dependencies...
python -m pip install --upgrade pip >nul
pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies from requirements.txt
    pause
    exit /b 1
)

REM --- Run the application ---
echo.
echo [*] Starting HOeditor...
echo.
python main.py

if errorlevel 1 (
    echo.
    echo [ERROR] The application exited with an error.
    pause
)

endlocal
