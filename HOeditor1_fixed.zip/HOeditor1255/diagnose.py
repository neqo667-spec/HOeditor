"""Диагностика: почему новые китайские теги (SIC, HBC, SND и т.д.) не видны
в редакторе ANKA. Запустите этот файл ИЗ ПАПКИ HOeditor1 (там же, где main.py)
через тот же Python/venv, что и сам редактор:

    .venv\\Scripts\\python diagnose.py

Он не трогает и не меняет ваши файлы — только читает и печатает отчёт.
"""
import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

def main():
    settings_path = Path(__file__).parent / "settings.json"
    if not settings_path.exists():
        print("!! settings.json не найден рядом со скриптом.")
        return
    settings = json.loads(settings_path.read_text(encoding="utf-8-sig"))
    game_path = Path(settings.get("game_path", ""))
    print(f"game_path из settings.json: {game_path}")
    print(f"  существует: {game_path.exists()}")
    print(f"  common/country_tags существует: {(game_path / 'common' / 'country_tags').is_dir()}")

    tag_dir = game_path / "common" / "country_tags"
    if tag_dir.is_dir():
        print(f"\nФайлы в common/country_tags:")
        for f in sorted(tag_dir.glob("*.txt")):
            print(f"  - {f.name} ({f.stat().st_size} bytes)")

    print("\n--- Пробуем прочитать через реальный парсер редактора ---")
    from anka.domain.mod import Mod, ModContext
    from anka.services.country_service import CountryService

    mods_root_local = Path(settings.get("local_mods_path", ""))
    mods_root_workshop = Path(settings.get("workshop_mods_path", ""))
    print(f"local_mods_path: {mods_root_local} (существует: {mods_root_local.exists()})")
    print(f"workshop_mods_path: {mods_root_workshop} (существует: {mods_root_workshop.exists()})")

    recent = settings.get("recent_mods", [])
    print(f"\nrecent_mods: {recent}")
    print("Укажите ниже, какой мод открывать для диагностики (введите точное имя папки мода,")
    print("либо просто нажмите Enter, чтобы проверить БЕЗ мода — только чтение base game).")
    mod_name = input("Имя папки мода (или Enter): ").strip()

    if mod_name:
        candidates = [mods_root_local / mod_name, mods_root_workshop / mod_name]
        mod_path = next((c for c in candidates if c.exists()), None)
        if mod_path is None:
            print(f"!! Папка мода не найдена ни в {mods_root_local}, ни в {mods_root_workshop}")
            return
    else:
        mod_path = Path(__file__).parent / "_diag_empty_mod"
        mod_path.mkdir(exist_ok=True)

    print(f"\nИспользуем mod.path = {mod_path}")
    mod = Mod(id="diag", name="Diagnose", path=mod_path, is_local=True)
    ctx = ModContext(mod=mod, game_path=game_path, dependencies=[])

    print(f"\ndlc_paths обнаруженные редактором:")
    for p in ctx.dlc_paths:
        print(f"  - {p}")
    if not ctx.dlc_paths:
        print("  (нет — это нормально, если у вас нет папки dlc/ или integrated_dlc/)")

    print(f"\noverride_layers для common/country_tags (низкий→высокий приоритет):")
    for root, is_mod in ctx.override_layers("common/country_tags"):
        print(f"  - {root}  (is_mod={is_mod}, existe={root.exists()})")

    svc = CountryService(ctx)
    refs = svc.list_tags(include_vanilla=True)
    print(f"\nВсего тегов найдено: {len(refs)}")

    wanted = {"SIC", "HBC", "SND", "NXM", "GSM", "GDC", "GDK", "KHM"}
    found = {r.tag: r for r in refs if r.tag in wanted}
    print(f"\nИскомые теги (SIC/HBC/SND/NXM/GSM/GDC/GDK/KHM):")
    for tag in sorted(wanted):
        if tag in found:
            r = found[tag]
            print(f"  ✔ {tag} -> {r.name}  (source={r.source_root}, vanilla={r.is_vanilla}, file={r.country_file})")
        else:
            print(f"  ✕ {tag} -> НЕ НАЙДЕН")

    print("\n--- Готово. Пришлите весь вывод выше. ---")

if __name__ == "__main__":
    main()
